@echo off
gradle %*
