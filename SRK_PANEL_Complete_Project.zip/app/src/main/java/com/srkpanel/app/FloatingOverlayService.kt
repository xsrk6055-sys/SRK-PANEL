package com.srkpanel.app

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class FloatingOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var overlay: View? = null
    private lateinit var params: WindowManager.LayoutParams

    private val black = Color.rgb(12, 12, 14)
    private val red = Color.rgb(255, 48, 48)
    private val white = Color.WHITE

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (overlay == null) showOverlay()
        return START_NOT_STICKY
    }

    private fun showOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 10, 12, 10)
            setBackgroundColor(black)
        }

        val header = TextView(this).apply {
            text = "☰  SRK PANEL   •   CLOSE"
            textSize = 16f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(12, 12, 12, 12)
            setBackgroundColor(red)
            gravity = Gravity.CENTER
            setOnClickListener { stopSelf() }
        }
        root.addView(header)

        val hint = TextView(this).apply {
            text = "DRAG HEADER TO MOVE  |  FLOATS OVER OTHER APPS"
            textSize = 10f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(4, 8, 4, 8)
        }
        root.addView(hint)

        listOf("AIM BOT", "AUTO HEADSHOT", "MOVEMENT", "FLY", "GHOST").forEach { label ->
            val b = Button(this).apply {
                text = label
                textSize = 12f
                setTextColor(white)
                setBackgroundColor(Color.rgb(170, 20, 30))
                setOnClickListener {
                    Toast.makeText(
                        this@FloatingOverlayService,
                        "$label — demo button only; no game modification.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
            root.addView(b, LinearLayout.LayoutParams(220, 46).apply {
                topMargin = 5
            })
        }

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 35
            y = 180
        }

        header.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var touchX = 0f
            private var touchY = 0f

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = initialX + (event.rawX - touchX).toInt()
                        params.y = initialY + (event.rawY - touchY).toInt()
                        wm.updateViewLayout(root, params)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (kotlin.math.abs(event.rawX - touchX) < 8 &&
                            kotlin.math.abs(event.rawY - touchY) < 8) {
                            stopSelf()
                        }
                        return true
                    }
                }
                return false
            }
        })

        overlay = root
        wm.addView(root, params)
    }

    override fun onDestroy() {
        overlay?.let {
            try { wm.removeView(it) } catch (_: Exception) {}
        }
        overlay = null
        super.onDestroy()
    }
}
