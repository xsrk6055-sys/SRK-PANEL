package com.srkpanel.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.os.Build
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 9, 11)
    private val panel = Color.rgb(24, 24, 28)
    private val red = Color.rgb(255, 48, 48)
    private val white = Color.WHITE
    private val muted = Color.rgb(175, 175, 180)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showLogin()
    }

    private fun baseLayout(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(26, 28, 26, 24)
            setBackgroundColor(bg)
        }
    }

    private fun title(text: String, size: Float = 30f): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(white)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
        }

    private fun field(hintText: String, password: Boolean = false): EditText =
        EditText(this).apply {
            hint = hintText
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 16f
            setSingleLine(true)
            setPadding(18, 12, 18, 12)
            setBackgroundColor(panel)
            if (password) inputType = 129
        }

    private fun button(label: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 15f
            setTextColor(white)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(red))
            setOnClickListener { onClick() }
        }

    private fun showLogin() {
        val root = baseLayout()
        root.gravity = Gravity.CENTER
        root.addView(title("SRK PANEL", 34f))
        val logoView = ImageView(this).apply {
            setImageResource(com.srkpanel.app.R.drawable.srk_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        root.addView(logoView, LinearLayout.LayoutParams(170, 170).apply { topMargin = 12; bottomMargin = 12 })
        val subtitle = TextView(this).apply {
            text = "BLACK  •  RED  •  GAMING DASHBOARD"
            setTextColor(red); textSize = 11f; gravity = Gravity.CENTER
        }
        root.addView(subtitle)
        val space = View(this)
        root.addView(space, LinearLayout.LayoutParams(1, 28))
        val username = field("Username")
        val password = field("Password", true)
        root.addView(username, matchWidth())
        root.addView(password, matchWidth().apply { topMargin = 12 })
        root.addView(button("LOGIN") {
            if (username.text.toString() == "srk" && password.text.toString() == "subscribe") {
                showDashboard()
            } else {
                Toast.makeText(this, "Invalid login. Demo: SRK / 1234", Toast.LENGTH_LONG).show()
            }
        }, matchWidth().apply { topMargin = 20 })
        val note = TextView(this).apply {
            text = "Username: srk  |  Password: subscribe"
            setTextColor(muted); textSize = 12f; gravity = Gravity.CENTER
        }
        root.addView(note)
        setContentView(root)
    }

    private fun showDashboard() {
        val root = baseLayout()
        root.gravity = Gravity.TOP
        root.addView(title("SRK PANEL", 32f))
        val logoView = ImageView(this).apply {
            setImageResource(com.srkpanel.app.R.drawable.srk_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        root.addView(logoView, LinearLayout.LayoutParams(130, 130).apply { topMargin = 8; bottomMargin = 8 })
        val sub = TextView(this).apply {
            text = "PRO GAMING TOOLS"
            setTextColor(red); textSize = 12f; gravity = Gravity.CENTER
        }
        root.addView(sub)
        val info = TextView(this).apply {
            text = "Welcome, SRK PLAYER"
            setTextColor(muted); textSize = 14f
            setPadding(0, 24, 0, 18)
        }
        root.addView(info)
        val features = listOf("AIM BOT", "AUTO HEADSHOT", "MOVEMENT", "FLY", "GHOST")
        features.forEach { name ->
            root.addView(button(name) {
                Toast.makeText(
                    this,
                    "$name — visual demo only; no game modification is performed.",
                    Toast.LENGTH_LONG
                ).show()
            }, matchWidth().apply { bottomMargin = 10 })
        }
        val disclaimer = TextView(this).apply {
            text = "NOTE: Ye buttons sirf demo interface hain. Ye Free Fire ko modify, inject ya control nahi karte."
            setTextColor(muted); textSize = 12f; gravity = Gravity.CENTER
            setPadding(4, 18, 4, 18)
        }
        root.addView(disclaimer)
        root.addView(button("ENABLE FLOATING OVERLAY") {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
                Toast.makeText(this, "SRK PANEL ko 'Display over other apps' permission dein, phir app me wapas aakar button dabayein.", Toast.LENGTH_LONG).show()
            } else {
                startService(Intent(this, FloatingOverlayService::class.java))
                Toast.makeText(this, "Floating menu started", Toast.LENGTH_SHORT).show()
            }
        }, matchWidth().apply { bottomMargin = 10 })
        root.addView(button("LOG OUT") { stopService(Intent(this, FloatingOverlayService::class.java)); showLogin() }, matchWidth())
        setContentView(root)
    }

    private fun matchWidth() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )
}
